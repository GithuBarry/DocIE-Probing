from dygie.models.dygie import DyGIE
